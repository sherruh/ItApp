package com.rentapp.model;

import java.util.Date;

public class Vehicle {
    private String title;
    private Date yearOfCar;
    private String city;
    private int price;

    public Vehicle(String title, Date yearOfCar, String city, int price) {
        this.title = title;
        this.yearOfCar = yearOfCar;
        this.city = city;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getYearOfCar() {
        return yearOfCar;
    }

    public void setYearOfCar(Date yearOfCar) {
        this.yearOfCar = yearOfCar;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
